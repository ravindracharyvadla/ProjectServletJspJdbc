package com.companyname.service;

import com.companyname.dao.PatientLoginDao;
import com.companyname.dao.PatientLoginDaoImpl;
import com.companyname.model.RegistrationModel;

public class PatientLoginServiceImpl implements PatientLoginService{

	@Override
	public boolean patientLogin(RegistrationModel model) {
		
		PatientLoginDao dao=new PatientLoginDaoImpl();
		
		return dao.patientLogin(model);	
	}

}

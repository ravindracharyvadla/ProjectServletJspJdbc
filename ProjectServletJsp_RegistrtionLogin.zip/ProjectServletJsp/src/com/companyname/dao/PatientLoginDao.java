package com.companyname.dao;

import com.companyname.model.RegistrationModel;

public interface PatientLoginDao {

	public boolean patientLogin(RegistrationModel model);
}

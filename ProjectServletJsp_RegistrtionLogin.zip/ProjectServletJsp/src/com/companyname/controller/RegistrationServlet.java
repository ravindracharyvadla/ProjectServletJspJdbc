package com.companyname.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.companyname.model.RegistrationModel;
import com.companyname.service.RegistrationService;
import com.companyname.service.RegistrationServiceImpl;


@WebServlet("/registration")
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void init() throws ServletException {
		System.out.println("Servlet Intialization");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//step-1: set the content type like html/xml/text/pdf/doc
		response.setContentType("text/html");
		
		//step-2: create an out object using PrintWriter class
		PrintWriter out=response.getWriter();
		
		//step-3:get the parameters from html or jsp form using getParameter()
		String userName=request.getParameter("userName");
		String password=request.getParameter("password");
		String contactNumber=request.getParameter("contactNumber");
		String emailId=request.getParameter("emailId");
		
		//step-4: Create an object for POJO/Model class and set the values
		RegistrationModel model=new RegistrationModel();
		model.setUserName(userName);
		model.setPassword(password);
		model.setContactNumber(contactNumber);
		model.setEmailId(emailId);
		
		//step-5: get the values from object of POJO/Model class and Display on Tomcat server
		out.print("<table border=1>");
			out.print("<tr>");
				out.print("<th>"+"User Name"+"</th>");
				out.print("<th>"+"Password"+"</th>");
				out.print("<th>"+"Contact Number"+"</th>");
				out.print("<th>"+"Email Id"+"</th>");
			out.print("</tr>");
			out.print("<tr>");
				out.print("<td>"+model.getUserName()+"</td>");
				out.print("<td>"+model.getPassword()+"</td>");
				out.print("<td>"+model.getContactNumber()+"</td>");
				out.print("<td>"+model.getEmailId()+"</td>");
			out.print("</tr>");
		out.print("</table>");
		
		//step-6:call service layer for database 
		RegistrationService service=new RegistrationServiceImpl();
		service.register(model);
		
		out.print("Registration has been successfully completed.");
		
	}

   public void destroy() {
		System.out.println("Detroy the server or close the server.");
	}
}

package com.companyname.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.companyname.model.RegistrationModel;
import com.companyname.service.PatientLoginService;
import com.companyname.service.PatientLoginServiceImpl;
import com.companyname.service.RegistrationService;
import com.companyname.service.RegistrationServiceImpl;


@WebServlet("/patientLogin")
public class PatientLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void init() throws ServletException {
		System.out.println("Servlet Intialization");
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//step-1: set the content type like html/xml/text/pdf/doc
				response.setContentType("text/html");
				
				//step-2: create an out object using PrintWriter class
				PrintWriter out=response.getWriter();
				
				//step-3:get the parameters from html or jsp form using getParameter()
				String userName=request.getParameter("userName");
				String password=request.getParameter("password");
				
				//step-4: Create an object for POJO/Model class and set the values
				RegistrationModel model=new RegistrationModel();
				model.setUserName(userName);
				model.setPassword(password);
				
				//step-6:call service layer for database 
				PatientLoginService service=new PatientLoginServiceImpl();
				boolean result=service.patientLogin(model);
				
				if(result==true){
				out.print("Login Success");
				}else{
					out.print("Login failed");
				}
	}

}

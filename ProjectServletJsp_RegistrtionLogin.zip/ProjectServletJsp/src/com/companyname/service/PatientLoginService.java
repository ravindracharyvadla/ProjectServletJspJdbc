package com.companyname.service;

import com.companyname.model.RegistrationModel;

public interface PatientLoginService {

	public boolean patientLogin(RegistrationModel model);
}

package com.companyname.service;

import java.util.List;

import com.companyname.dao.PatientShowDetailsDao;
import com.companyname.dao.PatientShowDetailsDaoImpl;
import com.companyname.model.RegistrationModel;

public class PatientShowDetailsServiceImpl implements PatientShowDetailsService{

	@Override
	public List<RegistrationModel> showPatientDetails() {
		// TODO Auto-generated method stub
		PatientShowDetailsDao dao=new PatientShowDetailsDaoImpl();
		return dao.showPatientDetails();
	}

}

package com.companyname.service;

import com.companyname.model.RegistrationModel;

public interface RegistrationService {

	public void register(RegistrationModel model); 
}

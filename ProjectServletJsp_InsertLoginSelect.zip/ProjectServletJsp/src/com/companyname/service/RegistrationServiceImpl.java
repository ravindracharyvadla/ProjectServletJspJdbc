package com.companyname.service;

import com.companyname.dao.RegistrationDao;
import com.companyname.dao.RegistrationDaoImpl;
import com.companyname.model.RegistrationModel;

public class RegistrationServiceImpl implements RegistrationService{

	@Override
	public void register(RegistrationModel model) {
		
		RegistrationDao dao=new RegistrationDaoImpl();
		dao.register(model);
		
	}

}

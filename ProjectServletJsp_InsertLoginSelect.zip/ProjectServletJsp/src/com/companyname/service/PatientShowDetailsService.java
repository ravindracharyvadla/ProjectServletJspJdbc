package com.companyname.service;

import java.util.List;

import com.companyname.model.RegistrationModel;

public interface PatientShowDetailsService {

	public List<RegistrationModel> showPatientDetails();
}

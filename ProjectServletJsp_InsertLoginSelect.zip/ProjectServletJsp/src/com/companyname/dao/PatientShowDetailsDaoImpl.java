package com.companyname.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.jws.WebParam.Mode;

import com.companyname.model.RegistrationModel;

public class PatientShowDetailsDaoImpl implements PatientShowDetailsDao{
	private final String db_username="root";
	private final String db_password="root";
	private final String db_driverClass="com.mysql.jdbc.Driver";
	private final String db_url="jdbc:mysql://localhost:3306/companyname";
	
	Connection connection=null;
	PreparedStatement pStatement=null;
	@Override
	public List<RegistrationModel> showPatientDetails() {
		List<RegistrationModel> list = null;
		try{
			//step-1: load the driver
			Class.forName(db_driverClass);
			
			//step-2:get the connection
			connection=DriverManager.getConnection(db_url, db_username, db_password);
			
			//step-3:Write your queries 
			String selectQuery="select * from registration_table";
			pStatement=connection.prepareStatement(selectQuery);
			
			//step:execute your statements
			ResultSet rs=pStatement.executeQuery();
			list=new ArrayList<RegistrationModel>();
			RegistrationModel model = null;
			while(rs.next()){
				
				model=new RegistrationModel();
				model.setUserName(rs.getString(1));
				model.setPassword(rs.getString(2));
				model.setContactNumber(rs.getString(3));
				model.setEmailId(rs.getString(4));
			
				list.add(model);
				
				System.out.println(rs.getString(1)+"\t"+rs.getString(2)+"\t"+rs.getString(3)+"\t"+rs.getString(4));
			}
			
		}catch(Exception exception){
			exception.printStackTrace();
		}finally{
			if(pStatement!=null){
				try {
					pStatement.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(connection!=null){
				try {
					connection.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return list;
		
		
		
	}

}

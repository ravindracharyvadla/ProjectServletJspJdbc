package com.companyname.dao;

import java.util.List;

import com.companyname.model.RegistrationModel;

public interface PatientShowDetailsDao {

	public List<RegistrationModel> showPatientDetails();
}

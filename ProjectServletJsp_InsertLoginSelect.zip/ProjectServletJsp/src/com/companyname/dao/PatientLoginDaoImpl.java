package com.companyname.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.companyname.model.RegistrationModel;

public class PatientLoginDaoImpl implements PatientLoginDao{
	private final String db_username="root";
	private final String db_password="root";
	private final String db_driverClass="com.mysql.jdbc.Driver";
	private final String db_url="jdbc:mysql://localhost:3306/companyname";
	
	Connection connection=null;
	PreparedStatement pStatement=null;
	boolean result=false;
	@Override
	public boolean patientLogin(RegistrationModel model) {
		
		try{
			//step-1: load the driver
			Class.forName(db_driverClass);
			
			//step-2:get the connection
			connection=DriverManager.getConnection(db_url, db_username, db_password);
			
			//step-3:Write your queries 
			String validateQuery="select * from registration_table where username=? and password=?";
			pStatement=connection.prepareStatement(validateQuery);
			
			//step-4:set the data
			pStatement.setString(1, model.getUserName());
			pStatement.setString(2, model.getPassword());
			
			
			//step-5:execute your statements
			ResultSet resultSet=pStatement.executeQuery();
			result=resultSet.next();
			
			if(result==true){
			System.out.println("login success");
			}else{
				System.out.println("login failed");
			}
			
		}catch(Exception exception){
			exception.printStackTrace();
		}finally{
			if(pStatement!=null){
				try {
					pStatement.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(connection!=null){
				try {
					connection.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return result;
		
	}

}

package com.companyname.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.companyname.model.RegistrationModel;


public class RegistrationDaoImpl implements RegistrationDao{

	private final String db_username="root";
	private final String db_password="root";
	private final String db_driverClass="com.mysql.jdbc.Driver";
	private final String db_url="jdbc:mysql://localhost:3306/companyname";
	
	Connection connection=null;
	PreparedStatement pStatement=null;
	
	
	@Override
	public void register(RegistrationModel model) {
		
		try{
			//step-1: load the driver
			Class.forName(db_driverClass);
			
			//step-2:get the connection
			connection=DriverManager.getConnection(db_url, db_username, db_password);
			
			//step-3:Write your queries 
			String insertQuery="insert into registration_table values(?,?,?,?)";
			pStatement=connection.prepareStatement(insertQuery);
			
			//step-4:set the data
			pStatement.setString(1, model.getUserName());
			pStatement.setString(2, model.getPassword());
			pStatement.setString(3, model.getContactNumber());
			pStatement.setString(4, model.getEmailId());
			
			//step-5:execute your statements
			pStatement.executeUpdate();
			
			System.out.println("Data has been successfully inserted.");
			
		}catch(Exception exception){
			exception.printStackTrace();
		}finally{
			if(pStatement!=null){
				try {
					pStatement.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if(connection!=null){
				try {
					connection.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
	}

}

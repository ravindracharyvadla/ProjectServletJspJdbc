package com.companyname.model.junit;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;


import com.companyname.model.RegistrationModel;


public class TestRegistrationModel {

	private RegistrationModel model;
	
	@Before
	public void setUp(){
		//create an object for model class in setUp() method
		model=new RegistrationModel();
		
		//set the values to model class
		model.setUserName("james");
		model.setPassword("james");
		model.setContactNumber("9876543210");
		model.setEmailId("james@gmail.com");
	}
	@Test
	public void test(){
		
		//test the values
		Assert.assertEquals("james", model.getUserName());
		Assert.assertEquals("james", model.getPassword());
		Assert.assertEquals("9876543210", model.getContactNumber());
		Assert.assertEquals("james@gmail.com", model.getEmailId());
	}
	@After
	public void shutDown(){
		System.out.println("---closed---");
	}
}

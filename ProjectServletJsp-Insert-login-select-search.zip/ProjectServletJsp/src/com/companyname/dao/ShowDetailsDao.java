package com.companyname.dao;

import java.util.List;

import com.companyname.model.RegistrationModel;

public interface ShowDetailsDao {

	public List<RegistrationModel> showPatientDetails();
}

package com.companyname.dao;

import com.companyname.model.RegistrationModel;

public interface LoginDao {

	public boolean patientLogin(RegistrationModel model);
}

package com.companyname.dao;

import com.companyname.model.RegistrationModel;

public interface RegistrationDao {

	public void register(RegistrationModel model);
}

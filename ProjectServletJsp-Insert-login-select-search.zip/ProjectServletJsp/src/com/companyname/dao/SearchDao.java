package com.companyname.dao;

import java.util.List;

import com.companyname.model.RegistrationModel;

public interface SearchDao {

	public List<RegistrationModel> searchInfo(String contactNumber);
}

package com.companyname.service;

import com.companyname.model.RegistrationModel;

public interface LoginService {

	public boolean patientLogin(RegistrationModel model);
}

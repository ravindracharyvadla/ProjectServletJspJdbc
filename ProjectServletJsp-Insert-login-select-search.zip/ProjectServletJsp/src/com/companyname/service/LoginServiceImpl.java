package com.companyname.service;

import com.companyname.dao.LoginDao;
import com.companyname.dao.LoginDaoImpl;
import com.companyname.model.RegistrationModel;

public class LoginServiceImpl implements LoginService{

	@Override
	public boolean patientLogin(RegistrationModel model) {
		
		LoginDao dao=new LoginDaoImpl();
		
		return dao.patientLogin(model);	
	}

}

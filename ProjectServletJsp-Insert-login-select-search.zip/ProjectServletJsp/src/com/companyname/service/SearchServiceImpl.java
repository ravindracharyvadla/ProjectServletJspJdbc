package com.companyname.service;

import java.util.List;

import com.companyname.dao.SearchDao;
import com.companyname.dao.SearchDaoImpl;
import com.companyname.model.RegistrationModel;

public class SearchServiceImpl implements SearchService{

	@Override
	public List<RegistrationModel> searchInfo(String contactNumber) {
		
		SearchDao dao=new SearchDaoImpl();
		return dao.searchInfo(contactNumber);
		
	}

}

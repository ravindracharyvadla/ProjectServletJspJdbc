package com.companyname.service;

import java.util.List;

import com.companyname.dao.ShowDetailsDao;
import com.companyname.dao.ShowDetailsDaoImpl;
import com.companyname.model.RegistrationModel;

public class ShowDetailsServiceImpl implements ShowDetailsService{

	@Override
	public List<RegistrationModel> showPatientDetails() {
		// TODO Auto-generated method stub
		ShowDetailsDao dao=new ShowDetailsDaoImpl();
		return dao.showPatientDetails();
	}

}

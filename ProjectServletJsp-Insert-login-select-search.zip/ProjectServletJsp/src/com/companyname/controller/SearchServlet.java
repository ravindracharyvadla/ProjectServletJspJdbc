package com.companyname.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.companyname.model.RegistrationModel;
import com.companyname.service.SearchService;
import com.companyname.service.SearchServiceImpl;


@WebServlet("/SearchServlet")
public class SearchServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		String contactNumber=request.getParameter("contactNumber");
		
		SearchService service=new SearchServiceImpl();
		List<RegistrationModel> list=service.searchInfo(contactNumber);
		boolean result=list.isEmpty();
		if(result==true){
			out.print("<h3>"+"No records found"+"</h3>");
		}else{
			out.print("<table border=1>");
			
			out.print("<tr>");
				out.print("<th>"+"User Name"+"</th>");
				out.print("<th>"+"Password"+"</th>");
				out.print("<th>"+"Contact Number"+"</th>");
				out.print("<th>"+"Email Id"+"</th>");
			out.print("</tr>");
			out.print("<tr>");
			
			for(RegistrationModel model:list){
				out.print("</tr>");
				out.print("<td>"+model.getUserName()+"</td>");
				out.print("<td>"+model.getPassword()+"</td>");
				out.print("<td>"+model.getContactNumber()+"</td>");
				out.print("<td>"+model.getEmailId()+"</td>");
				out.print("</tr>");
			}
			out.print("</table>");	
		}
		
		
		out.print("<a href='homePage.jsp'>"+"Home"+"<a>");
	}

}

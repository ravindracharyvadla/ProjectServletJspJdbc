package com.companyname.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.companyname.model.RegistrationModel;
import com.companyname.service.LoginService;
import com.companyname.service.LoginServiceImpl;
import com.companyname.service.RegistrationService;
import com.companyname.service.RegistrationServiceImpl;


@WebServlet("/loginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void init() throws ServletException {
		System.out.println("Servlet Intialization");
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//step-1: set the content type like html/xml/text/pdf/doc
				response.setContentType("text/html");
				
				//step-2: create an out object using PrintWriter class
				PrintWriter out=response.getWriter();
				
				//step-3:get the parameters from html or jsp form using getParameter()
				String userName=request.getParameter("userName");
				String password=request.getParameter("password");
				
				RequestDispatcher requestDispatcher;
				HttpSession httpSession;
				
				if(userName.equals("")&&password.endsWith("")){
					out.print("Please Enter User name and Password");
					requestDispatcher=request.getRequestDispatcher("index.jsp");
					requestDispatcher.include(request, response);
				}else{
					//step-4: Create an object for POJO/Model class and set the values
					RegistrationModel model=new RegistrationModel();
					model.setUserName(userName);
					model.setPassword(password);
					
					//step-6:call service layer for database 
					LoginService service=new LoginServiceImpl();
					boolean result=service.patientLogin(model);
					
					
					
					if(result==true){
						//we can access details in second servlet from first servlet using session
						httpSession=request.getSession();
						httpSession.setAttribute("userName", userName);
						httpSession.setAttribute("password", password);
						
						//forward to next servlet or jsp or html using RequestDispatcher
						requestDispatcher=request.getRequestDispatcher("LoginSuccessServlet");
						requestDispatcher.forward(request, response);
					//out.print("Login Success");
					}else{
						out.print("Login failed");
						requestDispatcher=request.getRequestDispatcher("index.jsp");
						requestDispatcher.include(request, response);
						
					}
				}
				
	}

}

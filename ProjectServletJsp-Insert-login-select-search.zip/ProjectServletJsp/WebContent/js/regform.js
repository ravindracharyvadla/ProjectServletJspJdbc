function registrationFormValidation(){
	
	//declare the variables and getting the properties from the html form
	var username=document.forms["formValidation"]["userName"];
	var password=document.forms["formValidation"]["password"];
	var contactNumber=document.forms["formValidation"]["contactNumber"];
	var emailId=document.forms["formValidation"]["emailId"];
	
	if(username.value==""){
		
		window.alert("Please Enter User Name");
		username.focus();
		
		return false;
	}
	
   if(password.value==""){
		
		window.alert("Please Enter password");
		password.focus();
		
		return false;
	}
   
   if(contactNumber.value==""){
		
		window.alert("Please Enter contactNumber");
		contactNumber.focus();
		
		return false;
	}
   
   if(emailId.value==""){
		
		window.alert("Please Enter emailId");
		emailId.focus();
		
		return false;
	}
	
	return true;
}